
---
doc_id: "DOC-EXT"
---

## SEC-A
```yaml
section_id: "SEC-A"
anchorage:
  view: "design"
  phase: "implementation"
```
Text.
