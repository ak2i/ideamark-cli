
# Sample

Some text without header YAML.
